### Hexlet tests and linter status:
<a href="https://codeclimate.com/github/zerg959/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/6f30822d6ecb0cc754cc/maintainability" /></a><br>
[![Actions Status](https://github.com/zerg959/python-project-lvl1/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/zerg959/python-project-lvl1/actions)
