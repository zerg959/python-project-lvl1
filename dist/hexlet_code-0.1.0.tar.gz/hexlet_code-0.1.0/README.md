### Hexlet tests and linter status:
<a href="https://codeclimate.com/github/zerg959/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/6f30822d6ecb0cc754cc/maintainability" /></a><br>
[![Actions Status](https://github.com/zerg959/python-project-lvl1/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/zerg959/python-project-lvl1/actions)


# 1. «Проверка на чётность» / Odd or even.
# https://asciinema.org/a/614684
Пользователю показывается случайное число. 
Необходимо ответить yes, если число чётное, или no — если нечётное.
Пользователь должен дать правильный ответ на три вопроса подряд. 
После успешной игры выводится поздравление

# 2. «Калькулятор» / Calculator.
# https://asciinema.org/a/IrvGL9iUHnaxWLYFuIlgqdmlb
Gользователю показывается случайное математическое выражение, 
например, 35 + 16, которое нужно вычислить и 
записать правильный ответ.
Пользователь должен дать правильный ответ на три вопроса подряд. 
После успешной игры выводится поздравление

